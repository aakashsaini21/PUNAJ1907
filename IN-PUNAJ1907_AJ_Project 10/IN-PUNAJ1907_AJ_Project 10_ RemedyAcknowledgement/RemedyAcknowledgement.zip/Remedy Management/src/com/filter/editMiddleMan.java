package com.filter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;
import com.models.User;

public class editMiddleMan extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
	{
		doPost(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	{
		try{
			Connection con = OrclDatabase.getConnection();

			HttpSession session = req.getSession();
			User u = (User)session.getAttribute("user");
			
			String query = "select * from users where email = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, u.getEmail());
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				RequestDispatcher rd = req.getRequestDispatcher("edit_profile.jsp?id="+rs.getInt(1)+"&fname="+rs.getString(2)+"&lname="+rs.getString(3)+"&mobile="+rs.getString(4)+"&email="+rs.getString(5));                                               
				rd.forward(req, res);
			}
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
