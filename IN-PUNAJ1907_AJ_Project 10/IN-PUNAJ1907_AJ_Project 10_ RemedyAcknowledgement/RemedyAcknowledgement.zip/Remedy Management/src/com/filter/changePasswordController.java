package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;

public class changePasswordController extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		System.out.println("get");
		doPost(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		HttpSession session = req.getSession();
		String password = req.getParameter("password");
		int userid = (int) session.getAttribute("userid");
		System.out.println(userid);
		try
		{
			Connection con = OrclDatabase.getConnection();
			String query = "update users set password = ? where userid = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, password);
			ps.setInt(2, userid);
			
			ps.executeUpdate();
			
			RequestDispatcher rd = req.getRequestDispatcher("index.jsp?msg=Password Changed successfully!");
			rd.forward(req, res);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
	}
}
