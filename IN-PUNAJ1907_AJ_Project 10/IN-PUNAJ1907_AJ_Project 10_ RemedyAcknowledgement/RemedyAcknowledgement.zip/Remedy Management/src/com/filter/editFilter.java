package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;
import com.models.User;

public class editFilter implements Filter{

	@Override
	public void destroy() {
		
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		
		HttpSession session = request.getSession();
		User u = (User) session.getAttribute("user");
		String mobile = req.getParameter("mobile");
		String email = req.getParameter("email");
		
		String ques = req.getParameter("securityQues");
		String ans = req.getParameter("answer");
		
		String currentPassword = req.getParameter("curPassword");
		
		String newPassword = req.getParameter("newPassword");
		
		
	try{
		Connection con = OrclDatabase.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String password = "";
		String q = "select password from users where email = ?";
		ps = con.prepareStatement(q);
		ps.setString(1, u.getEmail());
		rs = ps.executeQuery();
		while(rs.next())
		{
			password = rs.getString(1);
		}
		
		
		
		String query = "";
		if(password.equals(currentPassword))
		{
			if(ques.equals("nill") && ans.equals(""))
			{
				if(newPassword.equals("") || newPassword.equals(null))
				{
					query = "update users set mobileno = ?, email = ? where email = ?";
					ps = con.prepareStatement(query);
					ps.setString(1, mobile);
					ps.setString(2, email);
					ps.setString(3, u.getEmail());
					
					ps.executeUpdate();
					session.setAttribute("user", null);
					session.invalidate();
					req.getRequestDispatcher("index.jsp?msg=Profile edited successfully").forward(req, res);
				}
				else
				{
					query = "update users set mobileno = ?, email = ?, password = ? where email = ?";
					ps = con.prepareStatement(query);
					ps.setString(1, mobile);
					ps.setString(2, email);
					ps.setString(3, newPassword);
					ps.setString(4, u.getEmail());
					
					ps.executeUpdate();
					session.setAttribute("user", null);
					session.invalidate();
					req.getRequestDispatcher("index.jsp?msg=Profile edited successfully").forward(req, res);
				}
			}
			else
			{
				if(newPassword.equals("") || newPassword.equals(null))
				{
					query = "update users set mobileno = ?, email = ?, ques = ?, answer = ? where email = ?";
					ps = con.prepareStatement(query);
					ps.setString(1, mobile);
					ps.setString(2, email);
					ps.setString(3, ques);
					ps.setString(4, ans);
					ps.setString(5, u.getEmail());
					
					ps.executeUpdate();
					session.setAttribute("user", null);
					session.invalidate();
					req.getRequestDispatcher("index.jsp?msg=Profile edited successfully").forward(req, res);
				}
				else
				{
					query = "update users set mobileno = ?, email = ?, ques = ?, answer = ?, password = ? where email = ?";
					ps = con.prepareStatement(query);
					ps.setString(1, mobile);
					ps.setString(2, email);
					ps.setString(3, ques);
					ps.setString(4, ans);
					ps.setString(5, newPassword);
					ps.setString(6, u.getEmail());
					
					ps.executeUpdate();
					session.setAttribute("user", null);
					session.invalidate();
					req.getRequestDispatcher("index.jsp?msg=Profile edited successfully").forward(req, res);
				}
			}
		}else
		{
			req.getRequestDispatcher("edit_profile.jsp?msg=Please enter correct password to edit profile").forward(req, res);
		}
		
		
			
		
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
		
	}

}
