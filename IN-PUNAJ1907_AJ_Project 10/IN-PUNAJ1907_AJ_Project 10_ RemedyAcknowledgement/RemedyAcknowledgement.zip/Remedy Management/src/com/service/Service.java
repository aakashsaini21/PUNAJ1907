package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.chrono.IsoEra;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;

import javax.naming.spi.DirStateFactory.Result;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;
import com.models.User;
import com.models.UserRequest;

public class Service{
	public static void addUser(User u)
	{
		try
		{
			Connection con = OrclDatabase.getConnection();
			PreparedStatement ps = null;
			int userId = 0;
			
			
			//checking the userid in database
			String query = "select userid from users";
						 
			ps = con.prepareStatement(query,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = ps.executeQuery();
			if(rs.next() == false)
			{
				
				userId = 0;
				
			}	
			else
			{                                                                                                                                                                               
				
				rs.last();
				userId = rs.getInt(1);
				
			}
			
			userId = userId + 1;
			
			//adding user data to database 
			String query1 = "insert into users(userid, fname, lname, mobileno, email, password, ques, answer) values(?, ?, ?, ?, ?, ?, ?, ?)";
			ps = con.prepareStatement(query1);
			ps.setInt(1, userId);
			ps.setString(2, u.getFname());
			ps.setString(3, u.getLname());
			ps.setString(4, u.getMobile());
			ps.setString(5, u.getEmail());
			ps.setString(6, u.getPassword());
			ps.setString(7, u.getQues());
			ps.setString(8, u.getAns());
			
			ps.executeUpdate();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void addDetails(UserRequest u, String username)
	{
		try{
			  Connection con = OrclDatabase.getConnection();
			  PreparedStatement ps = null;
			  // finding userid of user
			  String query = "select Userid from users where email = ?";
			   
			  ps = con.prepareStatement(query);
			  ps.setString(1, username);
			  ResultSet rs = ps.executeQuery();
			  
			  int userid = 0;
			  while(rs.next())
			  {
				  userid = rs.getInt(1);
			  }
			  
			  //creating auto generating recordid
			  String recordId = "RA";
			  
			  Calendar c = Calendar.getInstance();
			  recordId += c.get(Calendar.DATE) + "" + c.get(Calendar.MONTH) + "" + c.get(Calendar.YEAR) + "" + c.get(Calendar.HOUR) + "" + c.get(Calendar.MINUTE) + "" + c.get(Calendar.SECOND);
			  
			  
			  //getting today's date
			  LocalDate l = LocalDate.now();
			  java.sql.Date date = java.sql.Date.valueOf(l);
			  
			  String query1 = "insert into userdetails values(?, ?, ?, ?, ?, ?, ?)";
			  ps = con.prepareStatement(query1);
			  
			  ps.setString(1, recordId);
			  ps.setString(2, u.getSummary());
			  ps.setString(3, u.getPriority());
			  ps.setString(4, date.toString());
			  ps.setString(5, u.getDetails());
			  ps.setString(6, "In-Progress");
			  ps.setInt(7, userid);
			 
			  ps.executeUpdate();
			  
			  
			  
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		  
		
		  
	}
	
	
	public static User validate(String username, String password)
	{
		User u = null;
		
		try
		{
			Connection con = OrclDatabase.getConnection();
			String query = "select * from users";
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ResultSet rs = ps.executeQuery(); 
			
			
			while(rs.next())
			{
				if(username.equals(rs.getString(5)) && password.equals(rs.getString(6)))
				{
					
					u = new User(rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
					break;
				}
				else
				{
					u = null;
				}
				
				
			}
			
			return u;
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return u;
		
	}
	
	public static ResultSet getUserId(User u) throws SQLException
	{
		Connection con = OrclDatabase.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String query1 = "select userid from users where email = ?";
		ps = con.prepareStatement(query1);
		
		ps.setString(1, u.getEmail());
		rs = ps.executeQuery();
		return rs;
	}
	
	public static ResultSet getUserDetails(int userid) throws SQLException
	{
		Connection con = OrclDatabase.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String query1 = "select * from userdetails where userid = ?";
		ps = con.prepareStatement(query1);
		
		ps.setInt(1, userid);
		rs = ps.executeQuery();
		return rs;
	}
	
	public static ResultSet getSummary() throws SQLException
	{
		Connection con = OrclDatabase.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String query1 = "select * from summary";
		ps = con.prepareStatement(query1);
		rs = ps.executeQuery();
		return rs;
	}
	
	public static ResultSet getSummary(int id) throws SQLException
	{
		Connection con = OrclDatabase.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String query1 = "select * from summary where summary_id = ?";
		ps = con.prepareStatement(query1);
		ps.setInt(1, id);
		rs = ps.executeQuery();
		return rs;
	}
	
	public static ResultSet getResources(int id) throws SQLException
	{
		Connection con = OrclDatabase.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String query1 = "select * from resources where summary_id = ?";
		ps = con.prepareStatement(query1);
		ps.setInt(1, id);
		rs = ps.executeQuery();
		return rs;
	}
	
	
	public static ResultSet getCustomRecords(String fromDate, String toDate, String status)
	{
		ResultSet rs = null;
		try
		{
			Connection con = OrclDatabase.getConnection();
			if(status.equals("nill"))
			{
				String query = "select * from userdetails where date1 > ? and date1 < ?";
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, fromDate);
				ps.setString(2, toDate);
				
				rs = ps.executeQuery();
			}
			else
			{
				String query = "select * from userdetails where date1 > ? and date1 < ? and status = ?";
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, fromDate);
				ps.setString(2, toDate);
				ps.setString(3, status);
				rs = ps.executeQuery();
			}
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
			
	}
	
	
	public static void sendMailtoAdmin(User user, UserRequest u)
	{

		try
		{
			Connection con = OrclDatabase.getConnection();
			PreparedStatement ps = null;
			int trans_id = 0;
			
			
			//checking the userid in database
			String query = "select trans_id from mails";
						 
			ps = con.prepareStatement(query,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = ps.executeQuery();
			if(rs.next() == false)
			{
				
				trans_id = 0;
				
			}	
			else
			{                                                                                                                                                                               
				
				rs.last();
				trans_id = rs.getInt(1);
				
			}
			
			trans_id = trans_id + 1;
			
			String query1 = "insert into mails values(?, ?, ?, ?, ?)";
			PreparedStatement ps1 = con.prepareStatement(query1);
			ps1.setInt(1, trans_id);
			ps1.setString(2, user.getEmail());
			ps1.setString(3, "admin@gmail.com");
			ps1.setString(4, u.getSummary());
			ps1.setString(5, u.getDetails());
			
			ps1.executeQuery();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
	
	public static void sendMailToUser(String recordID)
	{
		try
		{
			
		
			Connection con = OrclDatabase.getConnection();
			PreparedStatement ps = null;
			int trans_id = 0;
			
			
			//checking the userid in database
			String query = "select trans_id from mails";
						 
			ps = con.prepareStatement(query,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = ps.executeQuery();
			if(rs.next() == false)
			{
				
				trans_id = 0;
				
			}	
			else
			{                                                                                                                                                                               
				
				rs.last();
				trans_id = rs.getInt(1);
				
			}
			
			trans_id = trans_id + 1;
			
			String to = "";
			int userId = 0;
			String q = "select * from userdetails where recordid = ?";
			ps = con.prepareStatement(q);
			ps.setString(1, recordID);
			ResultSet rs1 = ps.executeQuery();
			UserRequest u = null;
			while(rs1.next())
			{
				userId = rs1.getInt(7);
				u = new UserRequest(rs1.getString(3), rs1.getString(2), rs1.getString(5));
			}
			
			
			String qu = "select email from users where userid = ?";
			ps = con.prepareStatement(qu);
			ps.setInt(1, userId);
			ResultSet rs2 = ps.executeQuery();
			while(rs2.next())
			{
				to = rs2.getString(1);
			}
			
			String m = "insert into mails values(?, ?, ?, ?, ?)";
			ps = con.prepareStatement(m);
			ps.setInt(1, trans_id);
			ps.setString(2, "admin@gmail.com");
			ps.setString(3, to);
			ps.setString(4, u.getSummary());
			ps.setString(5, u.getDetails());
			ps.executeQuery();
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
