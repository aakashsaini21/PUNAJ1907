package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;
import com.models.User;
import com.models.UserRequest;
import com.service.Service;

public class UserRequestMiddleMan extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doPost(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String priority = req.getParameter("priority");
		int summary_id = Integer.parseInt(req.getParameter("summary"));
		String details = req.getParameter("details");
		String summary = null;
		
		try{
			Connection con = OrclDatabase.getConnection();
			String query = "select * from summary where summary_id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, summary_id);
			
			ResultSet rs = ps.executeQuery();
			
			
			while(rs.next())
			{
				summary = rs.getString(2);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		UserRequest u = new UserRequest(priority, summary, details);
		
		HttpSession session = req.getSession();
		User u1 = (User)session.getAttribute("user");
		Service.addDetails(u ,u1.getEmail());
		Service.sendMailtoAdmin(u1, u);
		
		
		
		RequestDispatcher rd = req.getRequestDispatcher("UserProfile.jsp");
		rd.include(req, res);
		
	}
}
