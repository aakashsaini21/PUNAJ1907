package com.doa;

import java.sql.Connection;
import java.sql.DriverManager;

public class OrclDatabase {
	
	public static Connection getConnection()
	{
		
		Connection con = null;
		try
		{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "cognizant");
			
			
		}catch(Exception e)
		{
			
		}
		return con;
	}
	
	
}
