package com.filter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;
import com.models.User;
import com.service.Service;

public class LoginFilter implements Filter{

	@Override
	public void destroy() {
		
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
		String username = (String)req.getParameter("username");
		String password = (String)req.getParameter("password");
		
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		
		HttpSession session = request.getSession();
		
		if(session.getAttribute("user") == null)
		{
			
			User u = Service.validate(username, password);	
			if(u == null)
			{
				RequestDispatcher rd = req.getRequestDispatcher("index.jsp?msg=Invalid Username or Password!");
				rd.include(req, res);
			}
			else
			{
				session.setAttribute("user", u);
				chain.doFilter(req, res);
			}
			
		}
		/*else
		{
			System.out.println("jhfdskf");
			RequestDispatcher rd = req.getRequestDispatcher("index.jsp?msg=Invalid Username or Password!");
			rd.include(req, res);
		}*/
		
		
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
		
	}
	
}
