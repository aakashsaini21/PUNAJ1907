package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import com.doa.OrclDatabase;

/**
 * Servlet Filter implementation class forgotPassword
 */
@WebFilter("/forgotPassword")
public class forgotPassword implements Filter {

    /**
     * Default constructor. 
     */
    public forgotPassword() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		
		int userid = 0;
		try{
			Connection con  = OrclDatabase.getConnection();
			String q = "select * from users";
			
			PreparedStatement ps = con.prepareStatement(q);
			ResultSet rs = ps.executeQuery();
			boolean flag = false;
			while(rs.next())
			{
				if(request.getParameter("email").equals(rs.getString(5)))
				{
					userid = rs.getInt(1);
				}
			}
			
			String query = "select * from users where userid = ?";
			PreparedStatement ps1 = con.prepareStatement(query);
			ps1.setInt(1, userid);
			ResultSet rs1 = ps1.executeQuery();
			
			while(rs1.next())
			{
				
				if(request.getParameter("securityQues").equals(rs1.getString(7)) && request.getParameter("security").equals(rs1.getString(8)))
				{
					
					flag = true;
				}
			}
			
			if(userid == 0)
			{
				RequestDispatcher rd = request.getRequestDispatcher("forgotPassword.jsp?msg=user doesn't exist!");
				rd.include(request, response);
			}
			else if(flag == false)
			{
				RequestDispatcher rd = request.getRequestDispatcher("forgotPassword.jsp?msg=wrong security ques credentials!");
				rd.include(request, response);
			}
			else if(userid != 0 && flag == true)
			{
				request.setAttribute("userid", userid);
				
				chain.doFilter(request, response);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
